from io import StringIO
from pathlib import Path
import sys
import numpy as np
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from recommender import load_catalog, Recommender

@pytest.fixture
def model():
    return Recommender(load_catalog(Path(__file__).resolve().parents[1] / 'data/movies.csv'))

def test_ranking_filters_and_explanations(model):
    result = model.recommend('m001', ['Science Fiction'], 125)
    assert not result.empty
    assert 'm001' not in set(result.id)
    assert result.id.is_unique
    assert result.runtime.le(125).all()
    assert result.genre_list.apply(lambda gs: 'Science Fiction' in gs).all()
    assert result.score.is_monotonic_decreasing
    assert result.explanation.str.contains('Matching profile terms').all()
    assert 'm002' in result.id.values  # another botanical space-survival story

def test_feedback_changes_scores_and_excludes_rated_movies(model):
    before = model.recommend('m001', limit=100).set_index('id')
    after = model.recommend('m001', feedback={'m023': 1, 'm002': -1}, limit=100).set_index('id')
    assert 'm023' not in after.index and 'm002' not in after.index
    common = before.index.intersection(after.index)
    assert not np.allclose(before.loc[common, 'score'], after.loc[common, 'score'])
    reset = model.recommend('m001', feedback={})
    assert reset.id.tolist() == model.recommend('m001').id.tolist()

def test_empty_results(model):
    assert model.recommend('m001', max_runtime=1).empty
    assert model.recommend('m001', genres=['Unknown genre']).empty

def test_duplicate_ids_rejected(model):
    frame = model.catalog.drop(columns='genre_list').copy()
    frame.loc[1, 'id'] = frame.loc[0, 'id']
    with pytest.raises(ValueError, match='unique'):
        load_catalog(StringIO(frame.to_csv(index=False)))

@pytest.mark.parametrize('column,value', [('runtime', 'unknown'), ('runtime', 0), ('runtime', 90.5), ('description', ''), ('genres', '|'), ('year', 100)])
def test_invalid_catalog_rejected(model, column, value):
    frame = model.catalog.drop(columns='genre_list').copy().astype(object)
    frame.loc[0, column] = value
    with pytest.raises(ValueError):
        load_catalog(StringIO(frame.to_csv(index=False)))

def test_missing_columns_rejected():
    with pytest.raises(ValueError, match='Missing columns'):
        load_catalog(StringIO('title\nExample\n'))
