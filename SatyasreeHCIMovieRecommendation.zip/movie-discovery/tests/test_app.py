from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from streamlit.testing.v1 import AppTest

APP = str(Path(__file__).resolve().parents[1] / 'app.py')

def test_recommend_feedback_reset_and_empty_state():
    app = AppTest.from_file(APP).run(timeout=30)
    assert not app.exception
    next(b for b in app.button if b.label == 'Recommend movies').click().run()
    assert not app.exception
    assert len(app.subheader) > 1
    first_like = next(b for b in app.button if b.label == 'Interested')
    first_like.click().run()
    assert len(app.session_state['feedback']) == 1
    assert not app.exception
    next(b for b in app.button if b.label == 'Reset feedback').click().run()
    assert app.session_state['feedback'] == {}
    app.slider[0].set_value(1).run()
    assert any('No matching movies' in msg.value for msg in app.info)
    assert not app.exception
