"""Content-based recommendations with explicit, session-scoped feedback."""
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

REQUIRED = {'id', 'title', 'year', 'genres', 'runtime', 'description'}


def load_catalog(source):
    """Validate CSVs before fitting. Genres are separated by |."""
    frame = pd.read_csv(source).fillna('')
    missing = REQUIRED - set(frame.columns)
    if missing:
        raise ValueError('Missing columns: ' + ', '.join(sorted(missing)))
    frame = frame[list(sorted(REQUIRED))].copy()
    if len(frame) < 2:
        raise ValueError('Provide at least two movies.')
    for col in ['id', 'title', 'genres', 'description']:
        frame[col] = frame[col].astype(str).str.strip()
        if frame[col].eq('').any():
            raise ValueError(f'{col} must not be blank.')
    if frame.id.duplicated().any():
        raise ValueError('Movie IDs must be unique.')
    for col, low, high in [('runtime', 1, 1000), ('year', 1880, 2200)]:
        values = pd.to_numeric(frame[col], errors='coerce')
        if values.isna().any() or not values.between(low, high).all() or (values % 1 != 0).any():
            raise ValueError(f'{col} must contain whole numbers from {low} to {high}.')
        frame[col] = values.astype(int)
    frame['genre_list'] = frame.genres.apply(lambda s: sorted(set(g.strip() for g in s.split('|') if g.strip())))
    if frame.genre_list.apply(len).eq(0).any():
        raise ValueError('Each movie needs at least one genre.')
    return frame.reset_index(drop=True)


class Recommender:
    def __init__(self, catalog):
        self.catalog = catalog
        self.positions = {movie_id: i for i, movie_id in enumerate(catalog.id)}
        self.vectorizer = TfidfVectorizer(stop_words='english', ngram_range=(1, 2), sublinear_tf=True)
        # Repeat genres to give structured attributes more influence.
        genre_text = catalog.genre_list.apply(lambda gs: ' '.join(gs))
        documents = catalog.description + ' ' + genre_text + ' ' + genre_text
        try:
            self.matrix = self.vectorizer.fit_transform(documents)
        except ValueError as exc:
            raise ValueError('Catalog needs descriptive words beyond English stop words.') from exc
        self.terms = self.vectorizer.get_feature_names_out()

    def recommend(self, seed_id, genres=(), max_runtime=1000, feedback=None, limit=5):
        if seed_id not in self.positions:
            raise ValueError('Choose a movie in the current catalog.')
        feedback = {k: v for k, v in (feedback or {}).items() if k in self.positions and v in (-1, 1) and k != seed_id}
        seed = self.positions[seed_id]
        profile = self.matrix[seed].toarray()[0]
        for value, weight in [(1, 0.5), (-1, -0.25)]:
            positions = [self.positions[k] for k, v in feedback.items() if v == value]
            if positions:
                profile += weight * np.asarray(self.matrix[positions].mean(axis=0)).ravel()
        profile = np.maximum(profile, 0)
        scores = cosine_similarity(profile.reshape(1, -1), self.matrix).ravel()
        result = self.catalog.copy()
        result['score'] = scores
        mask = (result.id != seed_id) & ~result.id.isin(feedback) & (result.runtime <= max_runtime) & (result.score > 0)
        if genres:
            mask &= result.genre_list.apply(lambda gs: bool(set(gs) & set(genres)))
        result = result[mask].sort_values(['score', 'title', 'id'], ascending=[False, True, True]).head(limit).copy()
        explanations = []
        for row in result.itertuples():
            position = self.positions[row.id]
            shared = sorted(set(row.genre_list) & set(self.catalog.iloc[seed].genre_list))
            contributions = self.matrix[position].toarray()[0] * profile
            top = [self.terms[i] for i in np.argsort(-contributions) if contributions[i] > 0][:3]
            parts = []
            if shared:
                parts.append('Genres shared with your selection: ' + ', '.join(shared))
            if top:
                parts.append('Matching profile terms: ' + ', '.join(top))
            explanations.append('. '.join(parts) + '.')
        result['explanation'] = explanations
        return result
