"""Run with: streamlit run app.py"""
from pathlib import Path
from io import BytesIO
import hashlib
import streamlit as st
from recommender import load_catalog, Recommender

st.set_page_config(page_title='Movie Discovery', page_icon='🎬', layout='wide')
st.title('Movie Discovery')
st.write('Start with a movie you like. Find your next story.')
st.caption('Demo catalog: fictional movies and original descriptions, created for this project. No streaming availability is implied.')

with st.sidebar:
    st.header('Your catalog')
    upload = st.file_uploader('Optional: upload a movie CSV', type=['csv'], help='Required columns: id, title, year, genres, runtime, description. Separate genres with |.')
    st.caption('Files are processed by this running app. Feedback stays in this session; it is not saved to disk. A local launch makes no external API calls.')

raw = upload.getvalue() if upload else (Path(__file__).parent / 'data/movies.csv').read_bytes()
if len(raw) > 5_000_000:
    st.error('Choose a CSV smaller than 5 MB.')
    st.stop()

@st.cache_resource(show_spinner=False)
def build(content):
    catalog = load_catalog(BytesIO(content))
    if len(catalog) > 10000:
        raise ValueError('This demo supports up to 10,000 movies.')
    return Recommender(catalog)

try:
    model = build(raw)
except (ValueError, UnicodeError) as exc:
    st.error(f'Cannot use this catalog: {exc}')
    st.stop()

fingerprint = hashlib.sha256(raw).hexdigest()
if st.session_state.get('catalog_key') != fingerprint:
    st.session_state.catalog_key = fingerprint
    st.session_state.feedback = {}
    st.session_state.started = False
    for key in ['seed', 'genres', 'runtime', 'count']:
        st.session_state.pop(key, None)

catalog = model.catalog
labels = {r.id: f'{r.title} ({r.year}) · {r.id}' for r in catalog.itertuples()}
with st.sidebar:
    st.metric('Movies to explore', len(catalog))
    st.write(f'Feedback recorded: {len(st.session_state.feedback)}')
    if st.button('Reset feedback', use_container_width=True):
        st.session_state.feedback = {}
        st.rerun()

with st.container(border=True):
    seed = st.selectbox('Choose a movie you enjoyed', catalog.id.tolist(), format_func=labels.get, key='seed')
    a, b, c = st.columns([2, 2, 1])
    genres = a.multiselect('Genres (match any selected)', sorted({g for gs in catalog.genre_list for g in gs}), key='genres')
    runtime = b.slider('Maximum runtime (minutes)', 1, max(2, int(catalog.runtime.max())), int(catalog.runtime.max()), key='runtime')
    count = c.selectbox('Number of suggestions', [5, 3, 10], key='count')
    if st.button('Recommend movies', type='primary'):
        st.session_state.started = True

if st.session_state.started:
    results = model.recommend(seed, genres, runtime, st.session_state.feedback, count)
    st.subheader('Your recommendations')
    st.caption('Results refresh when you change preferences or give feedback. Similarity is a text match score, not a prediction of enjoyment.')
    if results.empty:
        st.info('No matching movies remain. Try more genres, increase the runtime, or reset feedback.')
    else:
        if len(results) < count:
            st.info(f'Found {len(results)} matching movies. Broaden your preferences for more.')
        for row in results.itertuples():
            with st.container(border=True):
                st.subheader(f'{row.title} ({row.year})')
                st.caption(f'{" · ".join(row.genre_list)} | {row.runtime} minutes | Similarity: {row.score:.3f}')
                st.write(row.description)
                st.write('**Why this movie?** ' + row.explanation)
                left, right = st.columns(2)
                if left.button('Interested', key=f'like_{row.id}', use_container_width=True):
                    st.session_state.feedback[row.id] = 1
                    st.rerun()
                if right.button('Not for me', key=f'dislike_{row.id}', use_container_width=True):
                    st.session_state.feedback[row.id] = -1
                    st.rerun()
        st.download_button('Download these recommendations', results.drop(columns='genre_list').to_csv(index=False), 'recommendations.csv', 'text/csv')

with st.expander('How recommendations work and project credits'):
    st.write('TF–IDF represents descriptions and genres. Cosine similarity ranks candidates against your selected movie and feedback. Interested adds 0.5 times the average liked vector; Not for me subtracts 0.25 times the average disliked vector. Negative profile weights are clipped to zero. Rated movies are removed from results. Reset feedback to undo all ratings.')
    st.write('Inspired by scikit-learn’s text-document example; this project uses similarity ranking instead of clustering and adds filters, explanations, and explicit feedback.')
    st.link_button('scikit-learn example and documentation', 'https://scikit-learn.org/stable/auto_examples/text/plot_document_clustering.html')
    st.caption('Built with Python, Streamlit, pandas, NumPy, and scikit-learn. See ATTRIBUTION.md for sources and AI assistance disclosure.')
